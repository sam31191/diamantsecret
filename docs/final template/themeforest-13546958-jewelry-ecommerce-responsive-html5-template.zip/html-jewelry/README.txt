1. Installation & User Guide: 
-----------------------
Extract file html_parallax-userguide.zip and read index.html for detail instruction.
	
2. Template Package:
-----------------
Extract file: html_parallax_rxx.zip and read the user guide above for detailed instruction.

3. PSD Design Files:
----------------
Extract file: parallax-design.zip